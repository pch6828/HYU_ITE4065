CREATE TABLE r4 (c0 bigint,c1 bigint);
copy r4 from 'r4.tbl' delimiter '|';
