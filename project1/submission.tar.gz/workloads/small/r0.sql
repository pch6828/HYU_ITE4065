CREATE TABLE r0 (c0 bigint,c1 bigint,c2 bigint);
copy r0 from 'r0.tbl' delimiter '|';
