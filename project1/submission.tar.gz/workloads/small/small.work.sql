SELECT SUM("1".c2), SUM("0".c1) FROM r3 "0", r0 "1", r1 "2" WHERE "0".c2="1".c0 and "0".c1="2".c0 and "0".c2>3499;
SELECT SUM("1".c1), SUM("0".c2), SUM("1".c0) FROM r5 "0", r0 "1" WHERE "0".c2="1".c0 and "0".c3=9881;
SELECT SUM("1".c0), SUM("0".c3), SUM("0".c4) FROM r9 "0", r0 "1", r2 "2" WHERE "0".c1="1".c0 and "1".c0="2".c2 and "0".c0>12472;
SELECT SUM("0".c3), SUM("1".c0) FROM r9 "0", r0 "1" WHERE "0".c1="1".c0 and "0".c1>1150;
SELECT SUM("1".c0) FROM r6 "0", r1 "1", r12 "2" WHERE "0".c1="1".c0 and "1".c0="2".c2 and "0".c0<62236;
SELECT SUM("2".c3), SUM("0".c1), SUM("0".c1) FROM r11 "0", r0 "1", r5 "2" WHERE "0".c2="1".c0 and "1".c0="2".c2 and "0".c1=5784;
SELECT SUM("3".c2), SUM("2".c2), SUM("2".c1) FROM r4 "0", r1 "1", r2 "2", r11 "3" WHERE "0".c1="1".c0 and "1".c0="2".c1 and "1".c0="3".c1 and "0".c1>2493;
SELECT SUM("0".c2), SUM("2".c5), SUM("2".c2) FROM r10 "0", r0 "1", r13 "2", r1 "3" WHERE "0".c2="1".c0 and "1".c0="2".c2 and "0".c1="3".c0 and "0".c1=209;
SELECT SUM("2".c0) FROM r6 "0", r1 "1", r11 "2", r5 "3" WHERE "0".c1="1".c0 and "1".c0="2".c1 and "1".c0="3".c1 and "0".c0>44809;
SELECT SUM("0".c2), SUM("0".c2) FROM r3 "0", r1 "1" WHERE "0".c1="1".c0 and "0".c2<3071;

SELECT SUM("2".c0), SUM("0".c1), SUM("2".c1) FROM r3 "0", r1 "1", r12 "2" WHERE "0".c1="1".c0 and "1".c0="2".c1 and "0".c0>26374;
SELECT SUM("0".c4), SUM("0".c0), SUM("1".c0) FROM r7 "0", r0 "1" WHERE "0".c1="1".c0 and "0".c4<9936;
SELECT SUM("1".c2), SUM("2".c3) FROM r2 "0", r1 "1", r9 "2" WHERE "0".c1="1".c0 and "1".c0="2".c2 and "0".c1=10731;
SELECT SUM("1".c2) FROM r5 "0", r1 "1" WHERE "0".c1="1".c0 and "0".c2=4531;
SELECT SUM("1".c2), SUM("2".c5), SUM("3".c5) FROM r3 "0", r0 "1", r13 "2", r13 "3" WHERE "0".c2="1".c0 and "1".c0="2".c1 and "2".c1="3".c2 and "0".c2<74;
SELECT SUM("0".c1), SUM("0".c3), SUM("0".c0) FROM r9 "0", r1 "1" WHERE "0".c2="1".c0 and "0".c1=1574;
SELECT SUM("1".c1), SUM("0".c1) FROM r0 "0", r5 "1" WHERE "0".c0="1".c2 and "1".c3=9855;
SELECT SUM("0".c0), SUM("0".c2), SUM("2".c3) FROM r11 "0", r0 "1", r2 "2" WHERE "0".c2="1".c0 and "1".c0="2".c2 and "0".c1<5283;
SELECT SUM("1".c1), SUM("1".c2), SUM("2".c5) FROM r8 "0", r0 "1", r7 "2" WHERE "0".c2="1".c0 and "1".c0="2".c1 and "0".c3>10502;
SELECT SUM("1".c0) FROM r9 "0", r1 "1", r11 "2" WHERE "0".c2="1".c0 and "1".c0="2".c1 and "1".c0="0".c2 and "0".c3>3991;
SELECT SUM("1".c1), SUM("0".c1), SUM("0".c1) FROM r4 "0", r1 "1" WHERE "0".c1="1".c0 and "0".c1<5730;
SELECT SUM("2".c2), SUM("3".c2) FROM r3 "0", r1 "1", r5 "2", r7 "3" WHERE "0".c1="1".c0 and "1".c0="2".c1 and "1".c0="3".c2 and "0".c2=4273;

SELECT SUM("2".c0) FROM r9 "0", r1 "1", r12 "2" WHERE "0".c2="1".c0 and "1".c0="2".c1 and "2".c2="1".c0 and "0".c2<2685;
SELECT SUM("0".c2), SUM("1".c3) FROM r1 "0", r12 "1", r2 "2" WHERE "0".c0="1".c2 and "0".c0="2".c1 and "1".c1="0".c0 and "1".c0>25064;
SELECT SUM("0".c0) FROM r2 "0", r0 "1" WHERE "0".c2="1".c0 and "0".c2<787;
SELECT SUM("1".c0), SUM("1".c1), SUM("0".c2) FROM r1 "0", r6 "1" WHERE "0".c0="1".c1 and "1".c1>10707;
SELECT SUM("2".c3), SUM("0".c0) FROM r13 "0", r0 "1", r3 "2" WHERE "0".c1="1".c0 and "1".c0="2".c2 and "0".c4=10571;
SELECT SUM("2".c1), SUM("0".c1), SUM("0".c2) FROM r12 "0", r1 "1", r6 "2", r12 "3" WHERE "0".c2="1".c0 and "1".c0="2".c1 and "0".c1="3".c2 and "3".c0<33199;
SELECT SUM("3".c3), SUM("2".c2) FROM r11 "0", r0 "1", r10 "2", r8 "3" WHERE "0".c2="1".c0 and "1".c0="2".c2 and "1".c0="3".c2 and "0".c0<9872;
SELECT SUM("1".c0) FROM r11 "0", r0 "1", r2 "2" WHERE "0".c2="1".c0 and "1".c0="2".c2 and "0".c1<4217;
SELECT SUM("1".c0), SUM("1".c2), SUM("0".c2) FROM r10 "0", r0 "1" WHERE "0".c2="1".c0 and "0".c2>1791;
SELECT SUM("1".c0) FROM r7 "0", r1 "1", r3 "2" WHERE "0".c2="1".c0 and "1".c0="2".c1 and "0".c3<8722;
SELECT SUM("0".c0), SUM("1".c2) FROM r4 "0", r1 "1", r9 "2" WHERE "0".c1="1".c0 and "1".c0="2".c2 and "0".c1>345;
SELECT SUM("3".c2) FROM r11 "0", r1 "1", r12 "2", r10 "3" WHERE "0".c1="1".c0 and "1".c0="2".c1 and "1".c0="3".c1 and "0".c2=598;
SELECT SUM("1".c2), SUM("1".c2) FROM r7 "0", r0 "1", r9 "2" WHERE "0".c1="1".c0 and "1".c0="0".c1 and "1".c0="2".c1 and "0".c1>3791;

SELECT SUM("0".c2) FROM r8 "0", r0 "1", r11 "2" WHERE "0".c2="1".c0 and "1".c0="2".c2 and "0".c3=9477;
SELECT SUM("3".c2), SUM("0".c0) FROM r0 "0", r13 "1", r7 "2", r10 "3" WHERE "0".c0="1".c2 and "0".c0="2".c1 and "0".c0="3".c2 and "1".c2>295;
SELECT SUM("2".c3), SUM("2".c1) FROM r7 "0", r1 "1", r3 "2" WHERE "0".c2="1".c0 and "1".c0="2".c1 and "1".c0="0".c2 and "0".c2>6082;
SELECT SUM("2".c0), SUM("3".c1) FROM r0 "0", r7 "1", r10 "2", r5 "3" WHERE "0".c0="1".c1 and "0".c0="2".c2 and "0".c0="3".c2 and "1".c3=8728;
SELECT SUM("1".c0), SUM("1".c0), SUM("3".c0) FROM r1 "0", r4 "1", r9 "2", r8 "3" WHERE "0".c0="1".c1 and "0".c0="2".c2 and "0".c0="3".c1 and "1".c1>2936;
SELECT SUM("1".c2), SUM("0".c1) FROM r4 "0", r1 "1" WHERE "0".c1="1".c0 and "0".c1<9795;
SELECT SUM("0".c1) FROM r11 "0", r1 "1" WHERE "0".c1="1".c0 and "0".c1<1688;
SELECT SUM("1".c0), SUM("0".c3) FROM r5 "0", r0 "1" WHERE "0".c2="1".c0 and "0".c0<1171;
SELECT SUM("2".c1), SUM("0".c1), SUM("0".c0) FROM r4 "0", r1 "1", r6 "2" WHERE "0".c1="1".c0 and "1".c0="2".c1 and "0".c0<13500;
SELECT SUM("1".c5) FROM r13 "0", r13 "1" WHERE "0".c1="1".c2 and "1".c6=8220;

SELECT SUM("1".c0), SUM("1".c1), SUM("1".c0) FROM r11 "0", r0 "1", r8 "2" WHERE "0".c2="1".c0 and "1".c0="2".c2 and "0".c2>4041;
SELECT SUM("0".c3), SUM("2".c0) FROM r8 "0", r0 "1", r10 "2" WHERE "0".c2="1".c0 and "1".c0="2".c2 and "0".c3<9473;
SELECT SUM("1".c2) FROM r5 "0", r1 "1", r8 "2" WHERE "0".c1="1".c0 and "1".c0="2".c1 and "0".c1<3560;
SELECT SUM("2".c0), SUM("2".c3), SUM("1".c2) FROM r13 "0", r0 "1", r2 "2" WHERE "0".c2="1".c0 and "1".c0="0".c1 and "1".c0="2".c2 and "0".c1>4477;
SELECT SUM("3".c3), SUM("2".c1), SUM("3".c6) FROM r8 "0", r0 "1", r13 "2", r13 "3" WHERE "0".c2="1".c0 and "1".c0="2".c2 and "2".c1="3".c2 and "0".c1>7860;

