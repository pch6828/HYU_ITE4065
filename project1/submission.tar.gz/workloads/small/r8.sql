CREATE TABLE r8 (c0 bigint,c1 bigint,c2 bigint,c3 bigint);
copy r8 from 'r8.tbl' delimiter '|';
